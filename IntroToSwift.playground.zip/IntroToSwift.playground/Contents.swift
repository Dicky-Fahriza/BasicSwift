import UIKit

var greeting = "Hello, playground"
var additionalGreet = "From the other side"

if greeting == "Hello" {
    // String interpolation
    print("\(greeting), \(additionalGreet)")
} else {
    print(greeting)
}
